/**
 * wyskakuje alert przywitania z podanym imieniem w parametrze
 * @param {string} somebody  imię
 * @returns None ('undefimd')
 *
 *@author bruno szwec 5d
 */
const sayHello = (somebody) => {
    alert(`hello ${somebody}`);
}
