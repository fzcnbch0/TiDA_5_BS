/**
 * dzieli parametr a przez b
 * @param {number} a - dzielna
 * @param {number }b - dzielnik
 * @throws {Error} if `b` is `0`
 * @returns {number} zwraca wynik dzielenia a przez b
 *
 * @example
 * const a=10;
 * const b=2;
 *
 * const result  = divide(a,b);
 * console.log(result);
 *  //logs : 5
 *
 *@author bruno szwec 5d
 */

function divide(a,b) {
    if (b!==0){
        return a/b;
    }
    else return "dziel przez 0";
}
const wynik = divide(4,0);
console.log(wynik);