/**
 * sprawdza czy osoba jest pełnoletnia
 * @param {number} age - wiek wyrażony w latach
 * @throws {Error} if `age` is lower than `0`
 * @returns {boolean} zwraca wartość true or false zależnie od tego czy osoba jest pełnoletnia
 *
 *@author bruno szwec 5d
 */

function isAdult(age) {
    if (age > 0) {

        if (age<18) return false;

        return true;
    }
    else return "ujemny wiek";
}
const wynik = isAdult(20)
console.log(wynik)