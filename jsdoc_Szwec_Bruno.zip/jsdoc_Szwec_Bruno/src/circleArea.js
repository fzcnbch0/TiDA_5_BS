/**
 * liczy pole koła na pdostawie podanego promienia
 * @param {number} r - promień koła
 * @throws {Error} if `r` is lower than `0`
 * @returns {number} zwraca pole koła
 *
 *@author bruno szwec 5d
 */

function calculateArea(r) {
    if (r > 0) {
        return Math.PI * r * r;
    }
    else return "promiń n może być ujemny";
}
const wynik = calculateArea(4)
console.log(wynik)